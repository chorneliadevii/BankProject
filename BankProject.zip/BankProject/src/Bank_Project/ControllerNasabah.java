package Bank_Project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class ControllerNasabah {

    private Connection conn;

    public ControllerNasabah() {
        DatabaseConnection db = new DatabaseConnection();
        this.conn = db.getConnection();
    }

    public ArrayList<Nasabah> getAllNasabah() throws SQLException {
        Statement st = null;
        ResultSet rs = null;
        ArrayList<Nasabah> data = new ArrayList();

        try {
            String query = "select * from nasabahpbo";
            st = conn.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                Nasabah nas = new Nasabah();
                nas.setNoRek(rs.getInt(1));
                nas.setNama(rs.getString(2));
                nas.setPin(rs.getInt(3));
                nas.setJenis(rs.getString(4));
                nas.setTagihan(rs.getDouble(5));
                nas.setSaldo(rs.getDouble(6));
                nas.setPekerjaaan(rs.getString(7));
                nas.setNIK(rs.getInt(8));
                nas.setJk(rs.getString(9));
                data.add(nas);
            }
        } catch (SQLException ex) {
            System.out.println("message : " + ex.getMessage());
        } finally {
            st.close();
            rs.close();
            conn.close();
        }
        return data;
    }

    public ArrayList<Nasabah> getNasabah(int norek) throws SQLException {
        Statement st = null;
        ResultSet rs = null;
        ArrayList<Nasabah> data = new ArrayList();
        int nr = norek;
        try {
            String query = "select * from nasabahpbo where no_rekening = " + nr;
            st = conn.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                Nasabah nas = new Nasabah();
                nas.setNoRek(rs.getInt(1));
                nas.setNama(rs.getString(2));
                nas.setPin(rs.getInt(3));
                nas.setJenis(rs.getString(4));
                nas.setTagihan(rs.getDouble(5));
                nas.setSaldo(rs.getDouble(6));
                nas.setPekerjaaan(rs.getString(7));
                nas.setNIK(rs.getInt(8));
                nas.setJk(rs.getString(9));
                data.add(nas);
            }
        } catch (SQLException ex) {
            System.out.println("message : " + ex.getMessage());
        } finally {
            st.close();
            rs.close();
            conn.close();
        }
        return data;
    }

    public void inputData(int norek, String nama, int pin, String jenis, double tagihan, double saldo,
            String kerja, int NIK, String jenisK) {
        conn = null;
        PreparedStatement ps = null;

        DatabaseConnection db = new DatabaseConnection();
        conn = db.getConnection();

        try {
            ps = conn.prepareStatement("insert into nasabahpbo values(?,?,?,?,?,?,?,?,?)");
            ps.setInt(1, norek);
            ps.setString(2, nama);
            ps.setInt(3, pin);
            ps.setString(4, jenis);
            ps.setDouble(5, tagihan);
            ps.setDouble(6, saldo);
            ps.setString(7, kerja);
            ps.setInt(8, NIK);
            ps.setString(9, jenisK);
            ps.executeQuery();
            conn.commit();
        } catch (SQLException ex) {
            System.out.println("message: " + ex.getMessage());
        } finally {
            try {
                ps.close();
                conn.close();
            } catch (SQLException ex) {
                System.out.println("message: " + ex.getMessage());
            }
        }
    }

    public void updateData(int norek, String nama, int pin, String jenis, double tagihan, double saldo, String kerja, int NIK, String jenisK) {
        conn = null;
        PreparedStatement ps = null;

        DatabaseConnection db = new DatabaseConnection();
        conn = db.getConnection();

        try {
            ps = conn.prepareStatement("update nasabahpbo set nama = ?, pin = ?, jenis = ?, tagihan = ?, saldo = ? "
                    + " , pekerjaan = ? , nik = ? , jenis_kelamin = ? where no_rekening = ?");
            ps.setString(1, nama);
            ps.setInt(2, pin);
            ps.setString(3, jenis);
            ps.setDouble(4, tagihan);
            ps.setDouble(5, saldo);
            ps.setString(6, kerja);
            ps.setInt(7,NIK);
            ps.setString(8, jenisK );
            ps.setInt(9, norek);
            ps.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            System.out.println("message: " + ex.getMessage());
        } finally {
            try {
                ps.close();
                conn.close();
            } catch (SQLException ex) {
                System.out.println("message: " + ex.getMessage());
            }
        }
    }

    public void TransferOut(int norekSrc, double trans) {
        conn = null;
        PreparedStatement ps = null;

        DatabaseConnection db = new DatabaseConnection();
        conn = db.getConnection();

        try {
            ps = conn.prepareStatement("update nasabahpbo set saldo = saldo - ? where no_rekening = ?");
            ps.setDouble(1, trans);
            ps.setInt(2, norekSrc);
            ps.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            System.out.println("message: " + ex.getMessage());
        } finally {
            try {
                ps.close();
                conn.close();
            } catch (SQLException ex) {
                System.out.println("message: " + ex.getMessage());
            }
        }
    }

    public void TransferIn(int norekDest, double trans) {
        conn = null;
        PreparedStatement ps = null;

        DatabaseConnection db = new DatabaseConnection();
        conn = db.getConnection();

        try {
            ps = conn.prepareStatement("update nasabahpbo set saldo = saldo + ? where no_rekening = ?");
            ps.setDouble(1, trans);
            ps.setInt(2, norekDest);
            ps.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            System.out.println("message: " + ex.getMessage());
        } finally {
            try {
                ps.close();
                conn.close();
            } catch (SQLException ex) {
                System.out.println("message: " + ex.getMessage());
            }
        }
    }

    public void deleteData(int norek) {

        conn = null;
        PreparedStatement ps = null;

        DatabaseConnection db = new DatabaseConnection();
        conn = db.getConnection();

        Scanner sc = new Scanner(System.in);

        try {
            ps = conn.prepareStatement("delete from nasabahpbo where no_rekening = ?");
            ps.setInt(1, norek);
            ps.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            System.out.println("message: " + ex.getMessage());
        } finally {
            try {
                ps.close();
                conn.close();
            } catch (SQLException ex) {
                System.out.println("message: " + ex.getMessage());
            }
        }
    }
}
