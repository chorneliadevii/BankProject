package Bank_Project;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ControllerTeller {

    private Connection conn;

    public ControllerTeller() {
        DatabaseConnection db = new DatabaseConnection();
        this.conn = db.getConnection();
    }

    public ArrayList<Teller> getAllTeller() throws SQLException {
        Statement st = null;
        ResultSet rs = null;

        ArrayList<Teller> data = new ArrayList();
        try {
            String query = "select * from teller";
            st = conn.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                Teller tel = new Teller();
                tel.setNip(rs.getInt(1));
                tel.setNama(rs.getString(2));
                tel.setPass(rs.getInt(3));
                data.add(tel);
            }
        } catch (SQLException ex) {
            System.out.println("message : " + ex.getMessage());
        } finally {
            st.close();
            rs.close();
            conn.close();
        }
        return data;
    }
}
