package Bank_Project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ControllerTransaksi {

    private Connection conn;

    public ControllerTransaksi() {
        DatabaseConnection db = new DatabaseConnection();
        this.conn = db.getConnection();
    }

    public ArrayList<History> getAllHistory() throws SQLException {
        Statement st = null;
        ResultSet rs = null;
        ArrayList<History> data = new ArrayList();

        try {
            String query = "select * from transaksi";
            st = conn.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                History riw = new History();
                riw.setNip(rs.getInt(1));
                riw.setNorek(rs.getInt(2));
                riw.setNominal(rs.getDouble(3));
                riw.setRiwayat(rs.getString(4));
                data.add(riw);
            }
        } catch (SQLException ex) {
            System.out.println("message : " + ex.getMessage());
        } finally {
            st.close();
            rs.close();
            conn.close();
        }
        return data;
    }

    public void inputData(int norek, int teller, Double nominal, String riwayat) {
        conn = null;
        PreparedStatement ps = null;

        DatabaseConnection db = new DatabaseConnection();
        conn = db.getConnection();

        try {
            ps = conn.prepareStatement("insert into transaksi values(?,?,?,?)");
            ps.setInt(1, teller);
            ps.setInt(2, norek);
            ps.setDouble(3, nominal);
            ps.setString(4, riwayat);
            ps.executeQuery();
            conn.commit();
        } catch (SQLException ex) {
            System.out.println("message: " + ex.getMessage());
        } finally {
            try {
                ps.close();
                conn.close();
            } catch (SQLException ex) {
                System.out.println("message: " + ex.getMessage());
            }
        }
    }

    public ArrayList<History> getHistory(int norek) throws SQLException {
        Statement st = null;
        ResultSet rs = null;
        ArrayList<History> data = new ArrayList();
        int nr = norek;
        try {
            String query = "select * from transaksi where no_rekening = " + nr;
            st = conn.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                History riw = new History();
                riw.setNip(rs.getInt(1));
                riw.setNorek(rs.getInt(2));
                riw.setNominal(rs.getDouble(3));
                riw.setRiwayat(rs.getString(4));
                data.add(riw);
            }
        } catch (SQLException ex) {
            System.out.println("message : " + ex.getMessage());
        } finally {
            st.close();
            rs.close();
            conn.close();
        }
        return data;
    }

}
