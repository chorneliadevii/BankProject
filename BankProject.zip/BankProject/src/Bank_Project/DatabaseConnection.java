package Bank_Project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private String jdbcURL = "jdbc:oracle:thin:@172.23.9.185:1521:orcl";
    private String user = "MHS185314136";
    private String password = "MHS185314136";
    private Connection connection = null;

    public DatabaseConnection() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            connection = DriverManager.getConnection(jdbcURL, user, password);
            System.out.println("koneksi berhasil");
        } catch (Exception ex) {
            System.out.println("message: " + ex.getMessage());
        }
    }

    public static void main(String[] args) throws SQLException {
        DatabaseConnection data = new DatabaseConnection();
    }

    public Connection getConnection() {
        return connection;
    }

}
