package Bank_Project;

public class Nasabah {

    private int noRek;
    private String nama;
    private int pin;
    private String jenis;
    private double tagihan;
    private double saldo;
    private String pekerjaaan;
    private int NIK;
    private String jk;
    


    public Nasabah() {
    }

    public Nasabah(int noRek, String nama, int pin, String jenis, double tagihan, double saldo, String pekerjaaan, int NIK, String jk) {
        this.noRek = noRek;
        this.nama = nama;
        this.pin = pin;
        this.jenis = jenis;
        this.tagihan = tagihan;
        this.saldo = saldo;
        this.pekerjaaan = pekerjaaan;
        this.NIK = NIK;
        this.jk = jk;
    }

    public int getNoRek() {
        return noRek;
    }

    public void setNoRek(int noRek) {
        this.noRek = noRek;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    public double getTagihan() {
        return tagihan;
    }

    public void setTagihan(double tagihan) {
        this.tagihan = tagihan;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getPekerjaaan() {
        return pekerjaaan;
    }

    public void setPekerjaaan(String pekerjaaan) {
        this.pekerjaaan = pekerjaaan;
    }

    public int getNIK() {
        return NIK;
    }

    public void setNIK(int NIK) {
        this.NIK = NIK;
    }

    public String getJk() {
        return jk;
    }

    public void setJk(String jk) {
        this.jk = jk;
    }
    
    
}
