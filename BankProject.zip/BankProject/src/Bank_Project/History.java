package Bank_Project;

public class History {

    private int nip;
    private int norek;
    private double nominal;
    private String riwayat;

    public History() {
    }

    public History(int nip, int norek, double nominal, String riwayat) {
        this.nip = nip;
        this.norek = norek;
        this.nominal = nominal;
        this.riwayat = riwayat;
    }

    public int getNip() {
        return nip;
    }

    public void setNip(int nip) {
        this.nip = nip;
    }

    public int getNorek() {
        return norek;
    }

    public void setNorek(int norek) {
        this.norek = norek;
    }

    public double getNominal() {
        return nominal;
    }

    public void setNominal(double nominal) {
        this.nominal = nominal;
    }

    public String getRiwayat() {
        return riwayat;
    }

    public void setRiwayat(String riwayat) {
        this.riwayat = riwayat;
    }

}
