package Bank_Project;

import java.sql.Date;

public class AkunBaru {

    private int noRek, nipT;
    private String date;

    public AkunBaru() {
    }

    public AkunBaru(int noRek, int nipT, String date) {
        this.noRek = noRek;
        this.nipT = nipT;
        this.date = date;
    }

    public int getNoRek() {
        return noRek;
    }

    public void setNoRek(int noRek) {
        this.noRek = noRek;
    }

    public int getNipT() {
        return nipT;
    }

    public void setNipT(int nipT) {
        this.nipT = nipT;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

}
