package Bank_Project;

public class Teller {

    private int nip;
    private String nama;
    private int pass;

    public Teller() {
    }

    
    public Teller(int nip, String nama, int pass) {
        this.nip = nip;
        this.nama = nama;
        this.pass = pass;
    }

    public int getNip() {
        return nip;
    }

    public void setNip(int nip) {
        this.nip = nip;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getPass() {
        return pass;
    }

    public void setPass(int pass) {
        this.pass = pass;
    }

}
