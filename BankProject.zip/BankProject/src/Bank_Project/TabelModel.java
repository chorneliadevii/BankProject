package Bank_Project;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class TabelModel extends AbstractTableModel {

    private List<Nasabah> nasabah = new ArrayList();

    public TabelModel(ArrayList<Nasabah> nas) {
        this.nasabah = nas;
    }

    @Override
    public int getRowCount() {
        return nasabah.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Nasabah data = nasabah.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return data.getNoRek();
            case 1:
                return data.getNama();
            case 2:
                return data.getJenis();
            case 3:
                return (long) data.getSaldo();
            case 4:
                return (long) data.getTagihan();
            default:
                return "";
        }
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "No.Rekening";
            case 1:
                return "Nama";
            case 2:
                return "Jenis Anggota";
            case 3:
                return "Saldo";
            case 4:
                return "Tagihan";
            default:
                return "";
        }
    }

}
