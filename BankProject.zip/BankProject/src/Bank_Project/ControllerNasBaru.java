package Bank_Project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ControllerNasBaru {

    private Connection conn;

    public ControllerNasBaru() {
        DatabaseConnection db = new DatabaseConnection();
        this.conn = db.getConnection();
    }

    public ArrayList<AkunBaru> getAllData() throws SQLException {
        Statement st = null;
        ResultSet rs = null;
        ArrayList<AkunBaru> data = new ArrayList();

        try {
            String query = "select * from buatakun";
            st = conn.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                AkunBaru akun = new AkunBaru();
                akun.setNipT(rs.getInt(1));
                akun.setNoRek(rs.getInt(2));
                akun.setDate(rs.getString(3));
                data.add(akun);
            }
        } catch (SQLException ex) {
            System.out.println("message : " + ex.getMessage());
        } finally {
            st.close();
            rs.close();
            conn.close();
        }
        return data;
    }

    public void inputData(int norek, int teller, String date) {
        conn = null;
        PreparedStatement ps = null;

        DatabaseConnection db = new DatabaseConnection();
        conn = db.getConnection();

        try {
            ps = conn.prepareStatement("insert into buatakun values(?,?,?)");
            ps.setInt(1, teller);
            ps.setInt(2, norek);
            ps.setString(3, date);
            ps.executeQuery();
            conn.commit();
        } catch (SQLException ex) {
            System.out.println("message: " + ex.getMessage());
        } finally {
            try {
                ps.close();
                conn.close();
            } catch (SQLException ex) {
                System.out.println("message: " + ex.getMessage());
            }
        }
    }

    
}
