package Bank_Project;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class TabelModelRiwayat extends AbstractTableModel {

    private List<History> nasabah = new ArrayList();

    public TabelModelRiwayat(ArrayList<History> nas) {
        this.nasabah = nas;
    }

    @Override
    public int getRowCount() {
        return nasabah.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        History data = nasabah.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return data.getNorek();
            case 1:
                return data.getNip();
            case 2:
                return (long) data.getNominal();
            case 3:
                return data.getRiwayat();
            default:
                return "";
        }
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "No.Rekening";
            case 1:
                return "Teller Yang Melayani";
            case 2:
                return "Nominal";
            case 3:
                return "Keterangan";
            default:
                return "";
        }
    }

}
